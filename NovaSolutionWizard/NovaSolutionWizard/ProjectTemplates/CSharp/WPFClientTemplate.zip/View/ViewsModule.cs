﻿using Ninject.Modules;

namespace $safeprojectname$
{
	/// <summary>
	/// Dependency Injection Module
	/// </summary>
	public class ViewsModule : NinjectModule
	{
		/// <summary>
		/// Loads the module into the kernel.
		/// </summary>
		public override void Load()
		{
			//TODO: Implement Dependency Injection
		}
	}
}
