﻿using Nova.Base;
using $safeprojectname$.Views;

namespace $safeprojectname$.ViewModel
{
	/// <summary>
	/// The main view model.
	/// </summary>
	public class MainViewModel : BaseViewModel<MainWindow, MainViewModel>
	{
	}
}
