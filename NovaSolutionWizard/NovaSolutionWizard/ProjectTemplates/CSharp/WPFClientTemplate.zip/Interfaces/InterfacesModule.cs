﻿using Ninject.Modules;

namespace $safesolutionname$
{
	/// <summary>
	/// Dependency Injection Module
	/// </summary>
	public class InterfacesModule : NinjectModule
	{
		/// <summary>
		/// Loads the module into the kernel.
		/// </summary>
		public override void Load()
		{
			//TODO: Implement Dependency Injection
		}
	}
}
